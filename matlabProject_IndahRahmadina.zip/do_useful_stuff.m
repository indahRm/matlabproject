function [ ] = do_useful_stuff( )
% Demonstrating simple text menu

clc;

fprintf('We are doing useful stuff.\n\n');

fprintf('Press any key to continue');
pause;

end

