function [ ] = do_fun_stuff( )
% Demonstrating simple text menu

clc;

fprintf('We are doing fun stuff.\n\n');

fprintf('Press any key to continue');
pause;

end

