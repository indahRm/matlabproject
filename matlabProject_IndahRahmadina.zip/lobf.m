line=true;
while line
    fprintf('What kind line would you like to fit %s with?\n', fileName);
    fprintf('1) Linear fit with non-zero y-intercept (y=mx+b).\n');
    fprintf('2) Linear fit with zero y-intercept (y=mx+b).\n');
    fprintf('3) General polynomial of degree n.\n');
    fprintf('4) More options...\n');
    fprintf('5) Return to graphing options.\n');
    choicel=input('Enter your choice: ','s');  
    
    hold on
    plot(x,y,'o');
    xlabel('X');
    ylabel('Y');
    switch choicel
        case '1' %lin fit (non-zero intercept)
            clc
            p = polyfit(x,y,1);
            yfit=polyval(p,x);
            plot(x,yfit);
            e = y - yfit;
            MSE = mean(e.^2);
            
            fprintf('The MSE is %.2f.', MSE);
            fprintf('\n\nPress any key to return to the graphing menu. ');
            line=false;
            pause;
        case '2' %lin fit (zero intercept)
            clc;
            fprintf('placeholder. go away.\n\n');
            line=false;
            pause;
        case '3' %gen polynomial
            clc;
            fprintf('placeholder. go away.\n\n');
            line=false;
            pause;
        case '4'
            clc;
            lobf2
        case '5'
            clc;
            line=false;    
        otherwise
            clc;
            fprintf('ERROR: Invalid input.\n')
            fprintf('I''m sorry, but that choice is not recognized.\nPlease try again.\n\n');
            fprintf('Press any key to return to the line of best fit menu.');
            pause;    
    end
end