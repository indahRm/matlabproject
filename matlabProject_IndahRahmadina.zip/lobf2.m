line2=true;
while line2
    fprintf('1) Exponential.\n');
    fprintf('2) Power Law.\n');
    fprintf('3) Trigonomic.\n');
    fprintf('4) Logarithmic.\n');
    fprintf('5) Reciprocal.\n');
    fprintf('4) Back...\n');
    fprintf('5) Return to graphing options.\n');
    choicel=input('Enter your choice: ','s');  
    
    hold on
    plot(x,y,'o');
    xlabel('X');
    ylabel('Y');
    switch choicel
        case '1' %lin fit (non-zero intercept)
            clc
            p = polyfit(x,y,1);
            yfit=polyval(p,x);
            plot(x,yfit);
            fprintf('Press any key to return to the graphing menu. ');
            line=false;
            pause;
        case '2' %lin fit (zero intercept)
            clc;
            fprintf('placeholder. go away.\n\n');
            line=false;
            pause;
        case '3' %gen polynomial
            clc;
            fprintf('placeholder. go away.\n\n');
            line=false;
            pause;
        case '4'
            clc;
            lobf2
        case '5'
            clc;
            line=false;    
        otherwise
            clc;
            fprintf('ERROR: Invalid input.\n')
            fprintf('I''m sorry, but that choice is not recognized.\nPlease try again.\n\n');
            fprintf('Press any key to return to the line of best fit menu.');
            pause;    
    end
end